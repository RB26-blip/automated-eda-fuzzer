﻿import os
import re
import matplotlib.pyplot as plt

def generate_waveforms():
    print("🎨 Parsing simulation logs to generate timing wave charts...")
    log_path = "telemetry/simulation_log.txt"
    output_image = "telemetry/synthesis_comparison_report.png"
    
    if not os.path.exists(log_path):
        print(f"Error: {log_path} not found. Run the simulator first.")
        return

    # Extract simulation data arrays using regular expressions
    times, resets, inputs, outputs = [], [], [], []
    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:
            match = re.search(r"\[TIME:\s*(\d+)ns\]\s*Reset:\s*(\d+)\s*\|\s*Input Data:\s*(\d+)\s*\|\s*Optimized Hardware Output:\s*(\d+)", line)
            if match:
                times.append(int(match.group(1)))
                resets.append(int(match.group(2)))
                inputs.append(int(match.group(3)))
                outputs.append(int(match.group(4)))

    if not times:
        print("Error: No valid simulation frames found in log file.")
        return

    # Set up a multi-tier timing diagram chart layout
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 6), sharex=True)
    fig.suptitle("Structural Verilog Module Behavioral Simulation Trace", fontsize=14, fontweight="bold")

    # Tier 1: Reset Signal (Digital Step Wave)
    ax1.step(times, resets, where="post", color="crimson", linewidth=2)
    ax1.set_ylabel("rst_n", fontsize=12, fontweight="bold")
    ax1.set_ylim(-0.2, 1.2)
    ax1.set_yticks([0, 1])
    ax1.grid(True, linestyle="--", alpha=0.5)

    # Tier 2: Data Input Value Tracking
    ax2.step(times, inputs, where="post", color="darkblue", linewidth=2)
    ax2.set_ylabel("data_in", fontsize=12, fontweight="bold")
    ax2.grid(True, linestyle="--", alpha=0.5)
    for t, val in zip(times, inputs):
        if val > 0: ax2.text(t + 0.5, val + 50, str(val), fontsize=9, color="darkblue")

    # Tier 3: Mathematically Verified Hardware Output Value Tracking
    ax3.step(times, outputs, where="post", color="forestgreen", linewidth=2)
    ax3.set_ylabel("data_out", fontsize=12, fontweight="bold")
    ax3.set_xlabel("Time (ns)", fontsize=12, fontweight="bold")
    ax3.grid(True, linestyle="--", alpha=0.5)
    for t, val in zip(times, outputs):
        if val > 0: ax3.text(t + 0.5, val + 1500, str(val), fontsize=9, color="forestgreen")

    plt.tight_layout()
    os.makedirs("telemetry", exist_ok=True)
    plt.savefig(output_image, dpi=300)
    print(f"Success! High-fidelity waveform graphic exported to: {output_image}")

if __name__ == "__main__":
    generate_waveforms()
