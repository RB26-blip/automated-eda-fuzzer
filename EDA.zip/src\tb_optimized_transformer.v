﻿`timescale 1ns / 1ps

module tb_optimized_transformer;

    // Inputs to the Device Under Test (DUT)
    reg clk;
    reg rst_n;
    reg [15:0] data_in;

    // Outputs from the DUT
    wire [15:0] data_out;

    // Instantiate the Formally Verified Module
    optimized_prst_transformer uut (
        .clk(clk),
        .rst_n(rst_n),
        .data_in(data_in),
        .data_out(data_out)
    );

    // Generate a continuous 100MHz Clock (10ns period)
    always #5 clk = ~clk;

    initial begin
        // Initialize log streaming for GTKWave visualization
        $dumpfile("telemetry/simulation_waves.vcd");
        $dumpvcdvars(0, tb_optimized_transformer);

        // System Reset Sequence
        clk = 0;
        rst_n = 0;
        data_in = 16'd0;
        #15;
        
        rst_n = 1; // Release reset
        #10;

        // Test Input Vector 1: Standard input
        data_in = 16'd2;
        #10; // Expected output on next edge: 2 * 31 = 62

        // Test Input Vector 2: High-density input boundary
        data_in = 16'd10;
        #10; // Expected output on next edge: 10 * 31 = 310

        // Test Input Vector 3: Max boundary simulation
        data_in = 16'd2000;
        #10; // Expected output on next edge: 2000 * 31 = 62000

        // End the simulation runtime loop cleanly
        #20;
        $display("Simulation successfully completed. Analyzing waves...");
        $finish;
    end

    // Monitor outputs in real-time inside the PowerShell console
    initial begin
        $monitor("[TIME: %0dns] Reset: %b | Input Data: %d | Optimized Hardware Output: %d", 
                 $time, rst_n, data_in, data_out);
    end

endmodule
