﻿#!/usr/bin/env python3
"""
Automated EDA Synthesis & Verification Platform
Input Translation Layer: Berkeley PLA (Programmable Logic Array) Parser
"""

import os
import numpy as np
from typing import Dict, List, Tuple, Any

class PLaParser:
    """
    Parses Berkeley PLA (.pla) files and maps them directly into 
    the In-Memory Bitmask Clustering Matrix format.
    """
    def __init__(self):
        self.num_inputs = 0
        self.num_outputs = 0
        self.input_names = []
        self.output_names = []
        
    def parse_file(self, file_path: str) -> Dict[str, Any]:
        """Reads an external PLA file path and processes its layout contents."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Target PLA layout not found at: {file_path}")
            
        # Using utf-8-sig automatically destroys the unwanted \ufeff BOM artifact
        with open(file_path, "r", encoding="utf-8-sig") as f:
            return self.parse_string(f.read())

    def parse_string(self, pla_content: str) -> Dict[str, Any]:
        """
        Parses a raw PLA string payload and generates an active truth table mapping.
        Supports standard truth symbols: '1' (asserted), '0' (negated), '-' (don't care).
        """
        # Clean whitespaces and completely ignore standard comment blocks
        lines = [line.strip() for line in pla_content.splitlines() if line.strip() and not line.strip().startswith('#')]
        cube_terms = []
        
        for line in lines:
            if line.startswith('.i '):
                self.num_inputs = int(line.split()[1])
            elif line.startswith('.o '):
                self.num_outputs = int(line.split()[1])
            elif line.startswith('.ilb '):
                self.input_names = line.split()[1:]
            elif line.startswith('.ob '):
                self.output_names = line.split()[1:]
            elif line.startswith('.'):
                continue
            else:
                parts = line.split()
                if len(parts) >= 2:
                    cube_terms.append((parts[0], parts[1]))
                    
        print(f"📊 PLA Parsing Complete: Found {self.num_inputs} Inputs, {self.num_outputs} Outputs, {len(cube_terms)} Product Terms.")
        return {
            "num_inputs": self.num_inputs,
            "num_outputs": self.num_outputs,
            "input_names": self.input_names if self.input_names else [f"in_{i}" for i in range(self.num_inputs)],
            "output_names": self.output_names if self.output_names else [f"out_{i}" for i in range(self.num_outputs)],
            "cube_terms": cube_terms
        }

if __name__ == "__main__":
    parser = PLaParser()
    target_pla = "src/control_unit.pla" if os.path.exists("src/control_unit.pla") else "control_unit.pla"
    if os.path.exists(target_pla):
        data = parser.parse_file(target_pla)
        print("Successfully Parsed File Cube Terms Matrix:", data["cube_terms"])
    else:
        sample_pla = ".i 4\n.o 2\n010- 10\n1-11 01\n.e"
        data = parser.parse_string(sample_pla)
        print("Fallback Parsed Cube Terms Matrix:", data["cube_terms"])
